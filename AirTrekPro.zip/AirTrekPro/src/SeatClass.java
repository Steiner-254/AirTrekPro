// JavaBean representing a FlightSeat
class FlightSeat {
    private boolean booked;

    public boolean isBooked() {
        return booked;
    }

    public void book() {
        booked = true;
    }
}

// Component representing a class of seats
class SeatClass {
    private final FlightSeat[][] seats;

    public SeatClass(int rows, int seatsPerRow) {
        seats = new FlightSeat[rows][seatsPerRow];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < seatsPerRow; j++) {
                seats[i][j] = new FlightSeat();
            }
        }
    }

    public int getRows() {
        return seats.length;
    }

    public int getSeatsPerRow() {
        return seats[0].length; // Assuming all rows have the same number of seats
    }

    public FlightSeat getSeat(int row, int seat) {
        return seats[row][seat];
    }
}
