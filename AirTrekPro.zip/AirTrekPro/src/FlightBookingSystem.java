import java.util.Scanner;

// Component representing the FlightBookingSystem
public class FlightBookingSystem {
    private static final int FIRST_CLASS_ROWS = 4;
    private static final int FIRST_CLASS_SEATS_PER_ROW = 8;
    private static final int SECOND_CLASS_ROWS = 6;
    private static final int SECOND_CLASS_SEATS_PER_ROW = 12;

    private final SeatClass firstClass;
    private final SeatClass secondClass;

    public FlightBookingSystem() {
        firstClass = new SeatClass(FIRST_CLASS_ROWS, FIRST_CLASS_SEATS_PER_ROW);
        secondClass = new SeatClass(SECOND_CLASS_ROWS, SECOND_CLASS_SEATS_PER_ROW);
    }

    public void bookSeat(String travelClass) {
        SeatClass selectedClass = (travelClass.equalsIgnoreCase("first")) ? firstClass : secondClass;

        for (int i = 0; i < selectedClass.getRows(); i++) {
            for (int j = 0; j < selectedClass.getSeatsPerRow(); j++) {
                FlightSeat seat = selectedClass.getSeat(i, j);
                if (!seat.isBooked()) {
                    seat.book();
                    System.out.println("Seat booked! Row: " + (i + 1) + ", Seat: " + (j + 1));
                    return;
                }
            }
        }
        System.out.println("Sorry, no available seats in the " + travelClass + " class.");
    }

    public static void main(String[] args) {
        FlightBookingSystem bookingSystem = new FlightBookingSystem();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Flight Booking System!");

        while (true) {
            System.out.println("\nSelect travel class (first/second) or type 'exit' to quit:");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            } else if (input.equalsIgnoreCase("first") || input.equalsIgnoreCase("second")) {
                bookingSystem.bookSeat(input);
            } else {
                System.out.println("Invalid input. Please select 'first', 'second', or 'exit'.");
            }
        }
        scanner.close();
        System.out.println("\nThank you for using the Flight Booking System!");
    }
}
